#ifndef MASSCAN_VERSION

#define MASSCAN_VERSION "1.3.9-integration"

#endif


#ifndef PROTO_MC_H
#define PROTO_MC_H
#include "proto-banner1.h"
#include "util-bool.h"

extern struct ProtocolParserStream banner_mc;

#endif

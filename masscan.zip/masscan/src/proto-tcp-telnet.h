#ifndef PROTO_TELNET_H
#define PROTO_TELNET_H
#include "proto-banner1.h"

extern const struct ProtocolParserStream banner_telnet;

#endif
